import MainContainer from "./screens/MainContainer";

function App() {
  return <MainContainer />;
}

export default App
